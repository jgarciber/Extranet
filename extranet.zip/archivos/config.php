<?php
    // Fichero: config.php
    // Datos acceso MySql
    $sql_host="localhost";
    $sql_usuario="admin";
    $sql_pass="administrador";
    $sql_db="iesalandalus";
    // $sql_host="extranet.jesusgarciber.es";
    // $sql_usuario="vczrdyal_admin";
    // $sql_pass="iesalandalusadmin";
    // $sql_db="vczrdyal_iesalandalus";
?>