<?php
    // Fichero: desconectabd.php
    // Cierra la conexión con MySql.
    $bd->close();
?>